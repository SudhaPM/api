package com.example.coupon_management_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CouponManagementApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
